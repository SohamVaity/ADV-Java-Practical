import java.io.*;
import java.net.*;

public class PrimeClient {
    public static void main(String[] args) {
        final String SERVER_IP = "localhost";
        final int SERVER_PORT = 12345;

        try {
            Socket clientSocket = new Socket(SERVER_IP, SERVER_PORT);

            // Create input and output streams
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter outToServer = new PrintWriter(clientSocket.getOutputStream(), true);

            // Send the number to the server
            outToServer.println(17); // Change this to the desired number

            // Read the result from the server and print it
            String resultMessage = inFromServer.readLine();
            System.out.println("Server says: " + resultMessage);

            // Close the connection with the server
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
