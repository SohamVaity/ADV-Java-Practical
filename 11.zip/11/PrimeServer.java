import java.io.*;
import java.net.*;

public class PrimeServer {
    public static void main(String[] args) {
        final int PORT = 12345;

        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server waiting for client connection on port " + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                // Create input and output streams
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter outToClient = new PrintWriter(clientSocket.getOutputStream(), true);

                // Read the number from the client
                int number = Integer.parseInt(inFromClient.readLine());

                // Check if the number is prime
                boolean isPrime = checkPrime(number);

                // Send the result to the client
                if (isPrime) {
                    outToClient.println(number + " is a prime number.");
                } else {
                    outToClient.println(number + " is not a prime number.");
                }

                // Close the connection with the current client
                clientSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean checkPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }
}
