import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) {
        final String SERVER_IP = "localhost";
        final int SERVER_PORT = 12345;

        try {
            Socket clientSocket = new Socket(SERVER_IP, SERVER_PORT);

            // Create input and output streams
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter outToServer = new PrintWriter(clientSocket.getOutputStream(), true);

            // Send the username to the server
            outToServer.println("SohamVaity");

            // Read the greeting message from the server and print it
            String greetingMessage = inFromServer.readLine();
            System.out.println("Server says: " + greetingMessage);

            // Close the connection with the server
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
